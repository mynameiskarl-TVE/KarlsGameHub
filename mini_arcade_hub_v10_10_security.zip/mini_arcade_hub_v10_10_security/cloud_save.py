"""Account-isolated Supabase cloud save loading and background uploading."""
from __future__ import annotations

from copy import deepcopy
import queue
import threading
import time
from typing import Any


class CloudSaveError(RuntimeError):
    pass


def fetch_player_save(client, user_id: str):
    """Fetch the signed-in player's save. RLS must limit rows to auth.uid()."""
    response = (
        client.table("player_saves")
        .select("save_data")
        .eq("user_id", user_id)
        .limit(1)
        .execute()
    )
    rows = getattr(response, "data", None) or []
    if not rows:
        return None
    return rows[0].get("save_data")


def upload_player_save(client, user_id: str, save_data: dict[str, Any]):
    """Upsert one JSON save row for this authenticated user."""
    response = (
        client.table("player_saves")
        .upsert(
            {"user_id": user_id, "save_data": deepcopy(save_data)},
            on_conflict="user_id",
        )
        .execute()
    )
    return response


def sync_leaderboard_profile(client, user_id: str, username: str, save_data: dict[str, Any]):
    """Update only the nickname; ranked score fields are server-owned."""
    safe = save_data if isinstance(save_data, dict) else {}
    nickname = str(safe.get("nickname") or username).strip()[:18] or username
    return (
        client.table("leaderboard")
        .update({"nickname": nickname})
        .eq("user_id", user_id)
        .execute()
    )

def fetch_leaderboard(client, limit: int = 100):
    """Read the shared scoreboard. RLS restricts access to signed-in users."""
    safe_limit = min(100, max(1, int(limit)))
    response = (
        client.table("leaderboard")
        .select("username,nickname,points,total_wins,blackjack_wins,mini_game_wins,trivia_correct,updated_at")
        .order("points", desc=True)
        .order("total_wins", desc=True)
        .limit(safe_limit)
        .execute()
    )
    return getattr(response, "data", None) or []


def fetch_my_status(client) -> dict:
    """Ask the server whether THIS account is suspended. Raises if the request fails."""
    response = client.rpc("mini_arcade_my_status", {}).execute()
    rows = getattr(response, "data", None) or []
    if isinstance(rows, dict):
        rows = [rows]
    if not rows:  # an account with no leaderboard row is not suspended
        return {"suspended": False, "reason": ""}
    row = rows[0]
    return {"suspended": bool(row.get("is_suspended")), "reason": str(row.get("reason") or "")[:200]}


class CloudSaveWorker:
    """Serialize cloud uploads off the Tkinter UI thread; local saves stay immediate."""

    _STOP = object()

    def __init__(self, client, user_id: str, username: str):
        self.client = client
        self.user_id = user_id
        self.username = username
        self._queue: queue.Queue = queue.Queue()
        self._thread = threading.Thread(target=self._run, name="MiniArcadeCloudSave", daemon=True)
        self._closed = False
        self._last_error = ""
        self._error_lock = threading.Lock()
        self._thread.start()

    def enqueue(self, save_data: dict[str, Any]):
        if not self._closed:
            self._queue.put(deepcopy(save_data))

    @property
    def last_error(self) -> str:
        with self._error_lock:
            return self._last_error

    def _run(self):
        stopping = False
        while not stopping:
            batch = [self._queue.get()]
            # The game saves several times per action. Only the newest save matters, so
            # collapse everything already waiting into one upload. This keeps the queue
            # from growing on a slow connection and avoids hitting Supabase rate limits.
            while True:
                try:
                    batch.append(self._queue.get_nowait())
                except queue.Empty:
                    break
            try:
                latest = None
                for entry in batch:
                    if entry is self._STOP:
                        stopping = True
                    else:
                        latest = entry
                if latest is not None:
                    try:
                        upload_player_save(self.client, self.user_id, latest)
                        sync_leaderboard_profile(self.client, self.user_id, self.username, latest)
                        with self._error_lock:
                            self._last_error = ""
                    except Exception as exc:  # offline play remains available
                        with self._error_lock:
                            self._last_error = " ".join(str(exc).split())[:220]
            finally:
                for _ in batch:
                    self._queue.task_done()

    def flush(self, timeout: float = 3.0) -> bool:
        deadline = time.monotonic() + timeout
        while self._queue.unfinished_tasks and time.monotonic() < deadline:
            time.sleep(0.05)
        return self._queue.unfinished_tasks == 0

    def close(self, timeout: float = 3.0) -> bool:
        if self._closed:
            return not self._thread.is_alive()
        self._closed = True
        flushed = self.flush(timeout)
        self._queue.put(self._STOP)
        self._thread.join(timeout=max(0.1, timeout))
        return flushed and not self._thread.is_alive()
